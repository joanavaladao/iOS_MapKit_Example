//
//  ViewController.swift
//  PhotoGPS
//
//  Created by Joana Valadao on 05/04/17.
//  Copyright © 2017 Joana Bittencourt. All rights reserved.
//

import UIKit
// Maps import
import MapKit
import CoreLocation
// Photo import (take a picture)
import MobileCoreServices

class ViewController: UIViewController, UIImagePickerControllerDelegate,
UINavigationControllerDelegate, CLLocationManagerDelegate, MKMapViewDelegate {
    
    // MARK: Properties
    @IBOutlet weak var photo: UIImageView!
    @IBOutlet weak var photoLocation: MKMapView!
    @IBOutlet weak var map: MKMapView!
    
    private var photoLatitude : Double!
    private var photoLongitude : Double!
    private var actualLatitude : Double!
    private var actualLongitude : Double!
    
    // manages the map
    let manager = CLLocationManager()
    
    
    // MARK: ViewController methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Setup manager
        manager.delegate = self
        manager.distanceFilter = kCLLocationAccuracyNearestTenMeters;
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.requestWhenInUseAuthorization()
        manager.startUpdatingLocation()
        
        // Setup map
        map.delegate = self
        map.showsUserLocation = true
        map.userTrackingMode = .follow
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Actions
    @IBAction func takePhoto(_ sender: UIButton) {
        print("entrei para tirar foto")
        // Test if the camera is available
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera) {
            
            let imagePicker = UIImagePickerController()
            
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.camera
            imagePicker.mediaTypes = [kUTTypeImage as String]
            imagePicker.allowsEditing = false
            
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    
    // MARK: Photo Controller
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let mediaType = info[UIImagePickerControllerMediaType] as! NSString

        self.dismiss(animated: true, completion: nil)

        if mediaType.isEqual(to: kUTTypeImage as String) {
            let image = info[UIImagePickerControllerOriginalImage] as! UIImage
            
            photo.image = image
            photoLatitude = actualLatitude!
            photoLongitude = actualLongitude!
            setMapRegion()
        }
    }
    
    // MARK: Map control

    //Getting the position and setting the map
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print("locationManager")
            // the array locations stores all the user's positions, and the position 0 is the most recent one
            let location = locations[0]
        
            self.actualLatitude = location.coordinate.latitude
            self.actualLongitude = location.coordinate.longitude
    }
    

    func setMapRegion() {
        
        print("setMapRegion")
        // here we define the map's zoom. The value 0.01 is a pattern
        let span:MKCoordinateSpan = MKCoordinateSpanMake(0.01, 0.01)
        
        let myLocation:CLLocationCoordinate2D = CLLocationCoordinate2DMake(photoLatitude!, photoLongitude!)
        
        let region:MKCoordinateRegion = MKCoordinateRegionMake(myLocation, span)
        
        //setting the map
        map.setRegion(region, animated: true)

        
            // Region data
            let title = "Photo Region"
            let coordinate = CLLocationCoordinate2DMake(photoLatitude!, photoLongitude!)
        
            // Setup annotation
            let userAnnotation = MKPointAnnotation()
            userAnnotation.coordinate = coordinate;
            userAnnotation.title = "\(title)";
            map.addAnnotation(userAnnotation)
    }

}

